/**
 * ******************  类说明  *********************
 * class       :  LoanContractActionEx.java
 * @author     :  赵静伟
 * @version    :  1.0  
 * description :  
 * @see        :                        
 * ***********************************************
 */
package com.hrt.app.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hrt.p2p.api.consts.CommonDef;
import com.hrt.p2p.api.model.BorrowerMerchantInfo;
import com.hrt.p2p.api.model.BorrowerPersonalInfo;
import com.hrt.p2p.api.model.CreditRightsApply;
import com.hrt.p2p.api.model.Loan;
import com.hrt.p2p.api.model.LoanInvestor;
import com.hrt.p2p.api.model.LoanPhase;
import com.hrt.p2p.api.model.User;
import com.hrt.p2p.api.util.DateTimeUtil;
import com.hrt.p2p.bridge.AppVars;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.html.simpleparser.HTMLWorker;
import com.lowagie.text.html.simpleparser.StyleSheet;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.hrt.p2p.api.consts.UserDef;
import com.hrt.p2p.exception.PlatformException;
import com.hrt.p2p.api.service.IBorrowerInfoService;
import com.hrt.p2p.api.service.IBorrowerService;
import com.hrt.p2p.api.service.ICreditRightsService;
import com.hrt.p2p.api.service.ILoanInvestorService;
import com.hrt.p2p.api.service.ILoanPicService;
import com.hrt.p2p.api.service.IInvestorService;
import com.hrt.p2p.api.service.ILoanService;
import com.hrt.p2p.api.service.IUserService;
import com.zkbc.core.util.LoanUtil;
import com.zkbc.front.invest.LoanContractAction;

/**
 * @author zhaojingwei
 *
 */
public class LoanContractActionEx extends LoanContractAction{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private static Logger logger = LoggerFactory.getLogger(LoanContractActionEx.class);
	
	
	private IUserService userService;
	private IBorrowerInfoService borrowerInfoService;
	private ILoanService loanService;
	private ILoanInvestorService loanInvestorService;
	private ICreditRightsService creditRightsService;
	
	private int loanId; 
	private Loan loan;
	private int applyId;
	public int getApplyId() {
		return applyId;
	}


	public void setApplyId(int applyId) {
		this.applyId = applyId;
	}


	private CreditRightsApply apply;
	private int id;
	private List<LoanInvestor> investorList;
	private User borrower;
	private User crSeller;
	private List<User> investorUserList;
	private BorrowerPersonalInfo borrowerPersonalInfo;
	private String webName;
	private String date;
	private String date_day;
	private String date_end;
	private String date_repayStart;
	private String monthRepay;
	private String lastMonthRepay;
	private List<LoanPhase> loanPhaseList;
	private IBorrowerService borrowerService;
	private IInvestorService investorService;
	private BorrowerMerchantInfo borrowerMerchantInfo;
	
	
	public void loanContractTemplate() throws PlatformException, ParseException, Exception{
		loan = loanService.getLoanByID(loanId);
		if (loan.getLoanType() == 4) { //融租贷合同范本生成
			loanContractTemplateForRZD();
		}else {
		String path = request.getRealPath("/contractTemplate/");
		String filename = "loanContractTemplate_" + loanId + ".pdf";
		String filepath = AppVars.getInstance().picRoot+"/contract/" + loanId;
		File dirFile = new File(filepath);
		if(!dirFile.exists()){
			dirFile.mkdirs();
		}
		File contractNoFile = new File(filepath,filename);
		if (!contractNoFile.exists() || contractNoFile.length() == 0) {
			Document document = new Document();
			StyleSheet st = new StyleSheet();
			st.loadTagStyle("body", "leading", "16,0");
			PdfWriter.getInstance(document,
					new FileOutputStream(contractNoFile));
			document.open();
			BaseFont bfChinese = BaseFont.createFont("STSongStd-Light",
					"UniGB-UCS2-H", false);
			Font fontChinese = new Font(bfChinese);
			ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"a.html"),"UTF-8"), st);
			for (int k = 0; k < p.size(); k++) {  
	            String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
	            t = t.replaceAll("\\$\\{loanId\\}", "");
	            t = t.replaceAll("\\$\\{start\\}", "");
	            t = t.replaceAll("\\$\\{end\\}", "");
	            t = t.replaceAll("\\,\\}", "");
	            if(t.length()!=0){ 
	            document.add(new Paragraph(t,fontChinese)); 
	            } 
	        }
			
			Font fontChinesetitle = new Font(bfChinese,Font.BOLD, 16);
	        document.newPage(); 
	        //协议的主体信息
	        document.add(new Paragraph("附录：",fontChinesetitle));
			document.add(new Paragraph("一、	协议主体信息",fontChinese));
			document.add(new Paragraph("甲方（出借人）",fontChinese));
			Table tb = new Table(3, 2);
			int widthtb[] = { 20, 30, 20};
			tb.setWidths(widthtb);
			tb.setWidth(100); // 占页面宽度 %
			tb.setPadding(1);
			tb.setSpacing(0);
			tb.setBorderWidth(1);
			Cell ac1 = new Cell(new Paragraph("姓名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			document.add(tb);
			document.add(new Paragraph("乙方（借款人）",fontChinese));
			tb = new Table(3, 2);
			tb.setWidths(widthtb);
			tb.setWidth(100); // 占页面宽度 %
			tb.setPadding(1);
			tb.setSpacing(0);
			tb.setBorderWidth(1);

			ac1 = new Cell(new Paragraph("姓名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			document.add(tb);
			document.add(new Paragraph("丙方（居间平台服务商）：北京放心科技服务有限公司",fontChinese));
			//借款基本信息
			
			document.add(new Paragraph("二、借款基本信息",fontChinese));
			Table t = new Table(2, 6);
			int width[] = { 20, 40};
			t.setWidths(width);
			t.setWidth(100); // 占页面宽度 %
			t.setPadding(1);
			t.setSpacing(0);
			t.setBorderWidth(1);
			
			Cell c2 = new Cell(new Paragraph("借款本金数额",fontChinese));
			t.addCell(c2);
			c2 = new Cell(new Paragraph("人民币【"+loan.getAmount().toString()+"】元",fontChinese));
			t.addCell(c2);
			
			Cell c3 = new Cell(new Paragraph("借款期限",fontChinese));
			t.addCell(c3);
			c3 = new Cell(new Paragraph(loan.getTermCount()+LoanUtil.getTermUnitStr().get(loan.getTermUnit()),fontChinese));
			t.addCell(c3);
			
			Cell c1 = new Cell(new Paragraph("借款用途",fontChinese));
			t.addCell(c1);
			c1 = new Cell(new Paragraph(LoanUtil.getborrowTypeStr().get(loan.getBorrowType()),fontChinese));
			t.addCell(c1);
			
			Cell c6 = new Cell(new Paragraph("还款方式",fontChinese));
			t.addCell(c6);
			c6 = new Cell(new Paragraph(LoanUtil.getProductNameMap().get(loan.getProductId()),fontChinese));
			t.addCell(c6);
			
			c2 = new Cell(new Paragraph("借款年利率",fontChinese));
			t.addCell(c2);
			c2 = new Cell(new Paragraph(loan.getAnnualInterestRate()+"%",fontChinese));
			t.addCell(c2);
			
			Cell c8 = new Cell(new Paragraph("还款日",fontChinese));
			t.addCell(c8);
			c8 = new Cell(new Paragraph("",fontChinese));

			t.addCell(c8);
			document.add(t);
				
		    //投资人角色回款计划表	
			document.add(new Paragraph("三、收益时间表",fontChinese));
			//回款计划表
		    Table tttt = new Table(5, 2);
			int widthtttt[] = { 15, 15, 15, 15, 15};
			tttt.setWidths(widthtttt);
			tttt.setWidth(100); // 占页面宽度 %
			tttt.setPadding(1);
			tttt.setSpacing(0);
			tttt.setBorderWidth(1);
			Cell cccc1 = new Cell(new Paragraph("回款序次数",fontChinese));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("回款时间",fontChinese)));
			tttt.addCell(cccc1);
			Cell cccc2 = new Cell(new Paragraph("本金",fontChinese));
			tttt.addCell(cccc2);
			cccc2 = new Cell(new Paragraph("利息",fontChinese));
			tttt.addCell(cccc2);
			cccc2 = new Cell(new Paragraph("账户管理费",fontChinese));
			tttt.addCell(cccc2);
			//还款计划表中的还款日期
			Cell cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tttt.addCell(cccc3);
			document.add(tttt);
			
			//收费标准
		    document.add(new Paragraph("四、收费规则与金额",fontChinese));
		    tttt = new Table(2, 7);
			int widthtttttt[] = {20, 80};
			tttt.setWidths(widthtttttt);
			tttt.setWidth(100); // 占页面宽度 %
			tttt.setPadding(1);
			tttt.setSpacing(0);
			tttt.setBorderWidth(1);
			cccc1 = new Cell(new Paragraph("收费项目",fontChinese));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("借款人",fontChinese)));
			tttt.addCell(cccc1);

			
			cccc1 = new Cell(new Paragraph(new Paragraph("借款管理费",fontChinese)));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("根据借款利率、期限、还款方式及风险评级的不同，按借款总金额年化0-10%计算，放款时一次性收取",fontChinese)));
			tttt.addCell(cccc1);
			
			cccc1 = new Cell(new Paragraph(new Paragraph("信用保险费",fontChinese)));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("根据风险评级不同，按借款总金额年化0-5%计算，放款时一次性收取",fontChinese)));
			tttt.addCell(cccc1);
			
			cccc1 = new Cell(new Paragraph(new Paragraph("借款逾期罚息",fontChinese)));
			tttt.addCell(cccc1);
//			cccc1 = new Cell(new Paragraph(new Paragraph("■逾期天数：1-30天\n√罚息总额=当期逾期本息总额×对应罚息利率×逾期天数\n√日罚息利率 "+AppVars.getInstance().faxiRate1+"%\n√罚息归出借人所有\n■逾期天数：30天以上\n√30天以上，不再累计罚息\n√此前累计罚息归"+AppVars.getInstance().websiteNameCn+"平台所有",fontChinese)));
			cccc1 = new Cell(new Paragraph(new Paragraph("向出借方支付",fontChinese)));
			tttt.addCell(cccc1);
			
			cccc1 = new Cell(new Paragraph(new Paragraph("借款逾期管理费",fontChinese)));
			tttt.addCell(cccc1);
//			cccc1 = new Cell(new Paragraph(new Paragraph("■逾期天数：1-30天\n√逾期管理费总额=（当期逾期本息总额+当期借款账户管理费）×对应逾期管理费率×逾期天数\n√逾期管理费率:"+AppVars.getInstance().yuqiRate1+"%\n■逾期天数：30天以上\n√逾期管理费总额=逾期30天内管理费总额+逾期30天后管理费总额\n√逾期30天后管理费总额=（当期逾期本息总额+借款待还本金）×对应逾期管理费率×(逾期天数-30)\n√逾期管理费率:"+AppVars.getInstance().yuqiRate2+"%",fontChinese)));
			cccc1 = new Cell(new Paragraph(new Paragraph("向丙方支付",fontChinese)));
			tttt.addCell(cccc1);
			
			 
			cccc1 = new Cell(new Paragraph(new Paragraph("提前还款补偿",fontChinese)));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("向出借方支付（补偿金额为剩余本金的  ％）",fontChinese)));
			tttt.addCell(cccc1);
			
			cccc1 = new Cell(new Paragraph(new Paragraph("上门催收提醒费用",fontChinese)));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("向丙方支付（人民币1000元／次）",fontChinese)));
			tttt.addCell(cccc1);
			
			document.add(tttt);
			
			document.close();
			
		}
		
		
		
		response.setContentType("application/pdf");
        FileInputStream in = new FileInputStream(contractNoFile);
        OutputStream o = response.getOutputStream();
        byte[] b = new byte[1024];
        while ((in.read(b)) != -1) {
            o.write(b);
        }
        o.flush();
        in.close();
        o.close();
        return;
		}
	}
	/**
	 * 
	 *@name    债转合同范本
	 *@description 相关说明
	 *@time    创建时间:2015-9-22下午05:17:25
	 *@throws PlatformException
	 *@throws ParseException
	 *@throws Exception
	 *@author   胡必武
	 *@history 修订历史（历次修订内容、修订人、修订时间等）
	 */

	public void creditRightContractTemplate() throws PlatformException, ParseException, Exception{
		loanId = loanInvestorService.getLoanInvestorById(id).getLoanId();
		loan = loanService.getLoanByID(loanId);
		String path = request.getRealPath("/contractTemplate/");
		String filename = "loanContractTemplate_" + id + ".pdf";
		String filepath = AppVars.getInstance().picRoot+"/contract/creditRight/" + id;
		File dirFile = new File(filepath);
		if(!dirFile.exists()){
			dirFile.mkdirs();
		}
		File contractNoFile = new File(filepath,filename);
		if (!contractNoFile.exists() || contractNoFile.length() == 0) {
			Document document = new Document();
			StyleSheet st = new StyleSheet();
			st.loadTagStyle("body", "leading", "16,0");
			PdfWriter.getInstance(document,
					new FileOutputStream(contractNoFile));
			document.open();
			BaseFont bfChinese = BaseFont.createFont("STSongStd-Light",
					"UniGB-UCS2-H", false);
			Font fontChinese = new Font(bfChinese);
			ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"b.html"),"UTF-8"), st);
			for (int k = 0; k < p.size(); k++) {  
				String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
				t = t.replaceAll("\\$\\{creditRightId\\}", "");
				t = t.replaceAll("\\$\\{signTime\\}", "");
				t = t.replaceAll("\\,\\}", "");
				if(t.length()!=0){ 
					document.add(new Paragraph(t,fontChinese)); 
				} 
			}
			
			Date end = loan.getReleaseTime();
			if (loan.getTermUnit() == 1){
				end = DateTimeUtil.getNextDate(end,loan.getTermCount());
				date_repayStart = new SimpleDateFormat("yyyy年MM月dd日").format(end);
				date_end = date_repayStart;
			}else{
				date_repayStart = nextMonth(end);
				for(int i = 0;i<loan.getTermCount();i++){
					date_end = nextMonth(end);
					end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
				}
			}
			//借款人信息
			borrower = userService.getUserByID(loan.getBorrowerId());
			
			Font fontChinesetitle = new Font(bfChinese,Font.BOLD, 16);
			document.newPage(); 
			//协议的主体信息
			document.add(new Paragraph("附录：",fontChinesetitle));
			document.add(new Paragraph("一、	协议主体信息",fontChinese));
			document.add(new Paragraph("甲方（转让人）",fontChinese));
			Table tb = new Table(3, 2);
			int widthtb[] = { 20, 30, 20};
			tb.setWidths(widthtb);
			tb.setWidth(100); 
			tb.setPadding(1);
			tb.setSpacing(0);
			tb.setBorderWidth(1);
			
			Cell ac1 = new Cell(new Paragraph("姓名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
			tb.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			
			document.add(tb);
			
			document.add(new Paragraph("乙方（受让人）",fontChinese));
			
			tb = new Table(3, 2);
			tb.setWidths(widthtb);
			tb.setWidth(100); 
			tb.setPadding(1);
			tb.setSpacing(0);
			tb.setBorderWidth(1);
			
			ac1 = new Cell(new Paragraph("姓名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
			tb.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(ac1);
			
			document.add(tb);
			
			document.add(new Paragraph("二、标的债权信息",fontChinese));
			Table t = new Table(2, 7);
			int width[] = { 20, 40};
			t.setWidths(width);
			t.setWidth(100); 
			t.setPadding(1);
			t.setSpacing(0);
			t.setBorderWidth(1);
			
			
			ac1 = new Cell(new Paragraph("借款ID",fontChinese));
			t.addCell(ac1);
			ac1 = new Cell(new Paragraph(loan.getLoanId().toString(),fontChinese));
			t.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("借款人姓名",fontChinese));
			t.addCell(ac1);
			ac1 = new Cell(new Paragraph(borrower.getRealName(),fontChinese));
			t.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("借款本金数额",fontChinese));
			t.addCell(ac1);
			ac1 = new Cell(new Paragraph("人民币【"+loan.getAmount().toString()+"】元",fontChinese));
			t.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("借款年利率",fontChinese));
			t.addCell(ac1);
			ac1 = new Cell(new Paragraph(loan.getAnnualInterestRate()+"%",fontChinese));
			t.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("原借款期限",fontChinese));
			t.addCell(ac1);
			if(loan.getTermUnit()==Short.parseShort("1")){
				ac1 = new Cell(new Paragraph(loan.getTermCount()+"天,从"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime())+"起，到"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getEndTime())+"止",fontChinese));
			}else if(loan.getTermUnit()==Short.parseShort("3")){
				ac1 = new Cell(new Paragraph(loan.getTermCount()+"个月,从"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime())+"起，到"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getEndTime())+"止",fontChinese));
			}
			t.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("月偿还本息数额",fontChinese));
			t.addCell(ac1);
			List<LoanPhase> loanPhaseList =  borrowerService.getLoanPhaseListbyLoanId(loan.getLoanId());
			String termRepay = "";
			for(int i=1;i<loanPhaseList.size()+1;i++){
				termRepay =termRepay+"第【" + i + "】期"+loanPhaseList.get(i-1).getPlannedTermAmount()+"元";
			}
			t.addCell(new Paragraph(termRepay,fontChinese));
			ac1 = new Cell(new Paragraph("还款日",fontChinese));
			t.addCell(ac1);
			if (loan.getProductId().equals(Short.parseShort("2"))){
				ac1 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
			}else{
				ac1 = new Cell(new Paragraph("每月【"+new SimpleDateFormat("dd").format(loan.getReleaseTime())+"】日（若当月没有该日，则还款日为当月最后一天，节假日不顺延；若该日为休息日的，则还款日为该日前最近的一个工作日）",fontChinese));
			}
			t.addCell(ac1);
			
			document.add(t);
			
			
			document.add(new Paragraph("三、标的债权转让信息",fontChinese));
			Table t3 = new Table(2, 5);
			t3.setWidths(width);
			t3.setWidth(100);
			t3.setPadding(1);
			t3.setSpacing(0);
			t3.setBorderWidth(1);
			
			ac1 = new Cell(new Paragraph("标的债权价值",fontChinese));
			t3.addCell(ac1);
			ac1 = new Cell(new Paragraph());
			t3.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("转让价款",fontChinese));
			t3.addCell(ac1);
			ac1 = new Cell(new Paragraph());
			t3.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("转让管理费",fontChinese));
			t3.addCell(ac1);
			ac1 = new Cell(new Paragraph());
			t3.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("转让日期",fontChinese));
			t3.addCell(ac1);
			ac1 = new Cell(new Paragraph());
			t3.addCell(ac1);
			
			ac1 = new Cell(new Paragraph("剩余还款分期月数",fontChinese));
			t3.addCell(ac1);
			ac1 = new Cell(new Paragraph());
			t3.addCell(ac1);
			document.add(t3);
			document.close();
			
		}
		
		
		
		response.setContentType("application/pdf");
		FileInputStream in = new FileInputStream(contractNoFile);
		OutputStream o = response.getOutputStream();
		byte[] b = new byte[1024];
		while ((in.read(b)) != -1) {
			o.write(b);
		}
		o.flush();
		in.close();
		o.close();
		return;
	}
	
	
	
	/**
	 * 
	 *@name    融租贷债转合同范本
	 *@description 相关说明
	 *@time    创建时间:2015-9-22下午05:17:25 2016-11-4 下午15:00：00
	 *@throws PlatformException
	 *@throws ParseException
	 *@throws Exception
	 *@author   周涛
	 *@history 修订历史（历次修订内容、修订人、修订时间等）
	 */
	public void loanContractTemplateForRZD() throws PlatformException, ParseException, Exception{
        
        loan = loanService.getLoanByID(loanId);
		String path = request.getRealPath("/contractTemplate/");
		String filename = "RZDContractTemplate_" + loanId + ".pdf";
		String filepath = AppVars.getInstance().picRoot+"/contract/" + loanId;
		File dirFile = new File(filepath);
		if(!dirFile.exists()){
			dirFile.mkdirs();
		}
		File contractNoFile = new File(filepath,filename);
        String anxinName = AppVars.getInstance().anxinName;
		String anxinAddress = AppVars.getInstance().anxinAddress;
		
		if (!contractNoFile.exists() || contractNoFile.length() == 0) {
			//转让人基本信息
			//borrowerMerchantInfo = borrowerInfoService.getBorrowerMerchantInfoByLoanId(loanId);
			Document document = new Document();
			StyleSheet st = new StyleSheet();
			st.loadTagStyle("body", "leading", "16,0");
			PdfWriter.getInstance(document,
					new FileOutputStream(contractNoFile));
			document.open();
			BaseFont bfChinese = BaseFont.createFont("STSongStd-Light",
					"UniGB-UCS2-H", false);
			Font fontChinese = new Font(bfChinese);
			
			ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"rzd.html"),"UTF-8"), st);
			for (int k = 0; k < p.size(); k++) {  
				String t = p.get(k).toString().replaceAll("[\\[||\\]]", "");
				t = t.replaceAll("\\$\\{realName\\}","" );
				t = t.replaceAll("\\$\\{idCard\\}","" );
				t = t.replaceAll("\\$\\{corporateName\\}","" );
				t = t.replaceAll("\\$\\{registeredAddress\\}","");
				t = t.replaceAll("\\$\\{anxinName\\}",anxinName );
				t = t.replaceAll("\\$\\{anxinAddress\\}",anxinAddress);
				t = t.replaceAll("\\$\\{amount\\}",loan.getAmount().toString());
				t = t.replaceAll("\\$\\{annualInterestRate\\}",loan.getAnnualInterestRate().toString());
				t = t.replaceAll("\\$\\{startDate\\}","");
				t = t.replaceAll("\\$\\{endDate\\}", "");
				t = t.replaceAll("\\,\\}", "");
				if(t.length()!=0){ 
					document.add(new Paragraph(t,fontChinese)); 
				} 
			}
			//协议的主体信息
			document.add(new Paragraph("甲方收款计划如下表所示：",fontChinese));
			Table tb = new Table(3, 2);
			int widthtb[] = { 25, 20, 20};
			tb.setWidths(widthtb);
			tb.setWidth(100); 
			tb.setPadding(1);
			tb.setSpacing(0);
			tb.setBorderWidth(1);
			Cell ac1 = new Cell(new Paragraph("收款日期",fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(new Paragraph("收款金额",fontChinese)));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("收款类型",fontChinese));
			tb.addCell(ac1);
			Cell cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(cccc3);
			cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(cccc3);
			cccc3 = new Cell(new Paragraph("\n",fontChinese));
			tb.addCell(cccc3);
			document.add(tb);
			
			ArrayList p1 = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"rzd1.html"),"UTF-8"), st);
			for (int k = 0; k < p1.size(); k++) {  
				String t = p1.get(k).toString().replaceAll("[\\[||\\]]", "");
				t = t.replaceAll("\\$\\{realName\\}","" );
				t = t.replaceAll("\\$\\{comName\\}", "");
				t = t.replaceAll("\\$\\{anxinName\\}",anxinName );
				t = t.replaceAll("\\,\\}", "");
				if(t.length()!=0){ 
					document.add(new Paragraph(t,fontChinese)); 
				} 
			}
			
			document.close();
			
		}
		
		
		
		response.setContentType("application/pdf");
		FileInputStream in = new FileInputStream(contractNoFile);
		OutputStream o = response.getOutputStream();
		byte[] b = new byte[1024];
		while ((in.read(b)) != -1) {
			o.write(b);
		}
		o.flush();
		in.close();
		o.close();
		return;
        
        
	}
		
	
	public void loanContract() throws PlatformException, ParseException, Exception{		
		//标信息
		loan = loanService.getLoanByID(loanId);
		borrower = userService.getUserByID(loan.getBorrowerId());
		String contractNo = "";
		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
		
		//根据文件名来下载
		if(super.getUser().getRoles()==UserDef.ROLE_INVESTOR){
			for(LoanInvestor loanInvestor : investorList){
				if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
					//投资人角色	
					contractNo = loanInvestor.getContractNo();
					break;
				}
			}
		}else{
			//借款人角色	
			contractNo = loan.getContractNo();
		}
		String filename = contractNo+".pdf";
		String filepath = AppVars.getInstance().picRoot+"/contract/"+loan.getLoanId();
		File dirFile = new File(filepath);
		if(!dirFile.exists()){
			dirFile.mkdirs();
		}
		File contractNoFile = new File(filepath,filename);
		if(!contractNoFile.exists() || contractNoFile.length()==0){
			if(super.getUser().getRoles()==UserDef.ROLE_INVESTOR){
				if (loan.getLoanType() == 4) { //融租贷投资者合同生成
					this.produceSignForInvstorForRZD(loan, contractNoFile, super.getUser());
				}
				else {
					this.produceSignForInvstor(loan, contractNoFile, super.getUser());
				}
			}else{
				this.produceSignForBorrower(loan, contractNoFile, super.getUser());
			}
			
		}
		response.setContentType("application/pdf");
        FileInputStream in = new FileInputStream(contractNoFile);
        OutputStream o = response.getOutputStream();
        byte[] b = new byte[1024];
        while ((in.read(b)) != -1) {
            o.write(b);
        }
        o.flush();
        in.close();
        o.close();
        return;
	}
	
	public void creditRightContract() throws PlatformException, ParseException, Exception{		
		//标信息
		CreditRightsApply apply = creditRightsService.getApplyByID(applyId);
		loan = loanService.getLoanByID(apply.getLoanId());
		crSeller = userService.getUserByID(apply.getSellerUserId());
		String crContractNo = "";
		investorList = loanInvestorService.getInvestorListByManagerNo(apply.getId().toString());
		
		//根据文件名来下载
		if(super.getUser().getRoles()==UserDef.ROLE_INVESTOR){
			for(LoanInvestor loanInvestor : investorList){
				if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
					//债权买入者	
					crContractNo = loanInvestor.getCrContractNo();
					break;
				}
			}
			
			
		}else{
			//债权卖出者	
			crContractNo = apply.getCrContractNo();
		}
		String filename = crContractNo+".pdf";
		String filepath = AppVars.getInstance().picRoot+"/contract/creditRight/"+loan.getLoanId();
		File dirFile = new File(filepath);
		if(!dirFile.exists()){
			dirFile.mkdirs();
		}
		File contractNoFile = new File(filepath,filename);
		if(!contractNoFile.exists() || contractNoFile.length()==0){
			if(super.getUser().getUserId().intValue()!=apply.getSellerUserId().intValue()){
				this.produceCRSignForBuyer(apply, contractNoFile, super.getUser());
			}else{
				this.produceCRSignForSeller(apply, contractNoFile, super.getUser());
			}
		}
		response.setContentType("application/pdf");
		FileInputStream in = new FileInputStream(contractNoFile);
		OutputStream o = response.getOutputStream();
		byte[] b = new byte[1024];
		while ((in.read(b)) != -1) {
			o.write(b);
		}
		o.flush();
		in.close();
		o.close();
		return;
		
	}
	
	/**
	 * ********************************************
	 * method name   : produceSignForInvstorForRZD 
	 * description   : 生成融租贷投资人的借款协议pdf格式
	 * @return       : void
	 * @param        : @param loan
	 * @param        : @param file
	 * @param        : @param user
	 * @param        : @throws Exception
	 * @Exception    : @throws Exception
	 * modified      : 周涛 , 2016-11-7 10:00
	 * @see          : 
	 * *******************************************
	 */
	public  void produceSignForInvstorForRZD(Loan loan,File file,User user) throws Exception{
        
		String path = request.getRealPath("/contractTemplate/");
		//常量
		webName = CommonDef.WEBSITE_DOMAIN_NAME;
		//标信息
		//投资人信息
		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
		//借款人信息
		borrower = userService.getUserByID(loan.getBorrowerId());
		//合同签订时间，取放标时间
		date = new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime());
		date_day = new SimpleDateFormat("dd").format(loan.getReleaseTime());
		
		String anxinName = AppVars.getInstance().anxinName; //丙方公司名
		String anxinAddress = AppVars.getInstance().anxinAddress;//注册地址
		Date end = loan.getReleaseTime();
		
		//lj mod 增加一次性还本付息的处理 这里简单处理，认为是以天为单位的都是一次还本付息的。
		if (loan.getTermUnit() == 1){
			end = DateTimeUtil.getNextDate(end,loan.getTermCount());
			date_repayStart = new SimpleDateFormat("yyyy年MM月dd日").format(end);
			date_end = date_repayStart;
		}else{
			date_repayStart = nextMonth(end);
			for(int i = 0;i<loan.getTermCount();i++){
				date_end = nextMonth(end);
				end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
			}
		}

		//借款人基本信息
		borrowerMerchantInfo = borrowerInfoService.getBorrowerMerchantInfoByLoanId(loanId);
		Document document = new Document();
		StyleSheet st = new StyleSheet();
		st.loadTagStyle("body", "leading", "16,0");
		PdfWriter.getInstance(document,
				new FileOutputStream(file));
		document.open();
		BaseFont bfChinese = BaseFont.createFont("STSongStd-Light",
				"UniGB-UCS2-H", false);
		Font fontChinese = new Font(bfChinese);
		
		ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"rzd.html"),"UTF-8"), st);
		for (int k = 0; k < p.size(); k++) {  
			String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
			t = t.replaceAll("\\$\\{realName\\}",user.getRealName() );
			t = t.replaceAll("\\$\\{idCard\\}",user.getIdCardNo() );
			t = t.replaceAll("\\$\\{corporateName\\}",borrowerMerchantInfo.getCorporateName() );
			t = t.replaceAll("\\$\\{registeredAddress\\}",borrowerMerchantInfo.getRegisteredAddress());
			t = t.replaceAll("\\$\\{anxinName\\}", anxinName);
			t = t.replaceAll("\\$\\{anxinAddress\\}",anxinAddress);
			t = t.replaceAll("\\$\\{amount\\}",loan.getAmount().toString());
			t = t.replaceAll("\\$\\{annualInterestRate\\}",loan.getAnnualInterestRate().toString());
			t = t.replaceAll("\\$\\{startDate\\}",date);
			t = t.replaceAll("\\$\\{endDate\\}", new SimpleDateFormat("yyyy年MM月dd日").format(end));
			t = t.replaceAll("\\,\\}", "");
			if(t.length()!=0){ 
				document.add(new Paragraph(t,fontChinese)); 
			} 
		}
	
		//投资人基本信息
		LoanInvestor investor = null;
		for(LoanInvestor loanInvestor : investorList){
			if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
				investor = loanInvestor;
				break;
			}
		}
		//回款计划表
	    List<LoanPhase> loanPhaseList  = investorService.repayToInvestors(loan,investor);
		//协议的主体信息
		document.add(new Paragraph("甲方收款计划如下表所示：",fontChinese));
		Table tb = new Table(3, loanPhaseList.size()+1);
		int widthtb[] = { 25, 20, 20};
		tb.setWidths(widthtb);
		tb.setWidth(100); 
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		Cell ac1 = new Cell(new Paragraph("收款日期",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("收款金额",fontChinese)));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph("收款类型",fontChinese));
		tb.addCell(ac1);
	    List<LoanPhase> phaseList =  borrowerService.getLoanPhaseListbyLoanId(loan.getLoanId());
		for (int i = 0; i < loanPhaseList.size(); i++) {
			LoanPhase loanPhase = loanPhaseList.get(i);
			Date dueDate = phaseList.get(loanPhase.getPhaseNumber()-1).getDueDate();//回款时间
			String repayDay = new SimpleDateFormat("yyyy年MM月dd日").format(dueDate);
			Cell ccc3 = new Cell(new Paragraph(repayDay,fontChinese));
			tb.addCell(ccc3);
			if (i != loanPhaseList.size()-1) {
				ccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermInterest().toString(),fontChinese));
				tb.addCell(ccc3);
				ccc3 = new Cell(new Paragraph("利息",fontChinese));
				tb.addCell(ccc3);
			}else {
				ccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermInterest().add(loanPhase.getPlannedTermPrincipal()).toString(),fontChinese));
				tb.addCell(ccc3);
				ccc3 = new Cell(new Paragraph("本息",fontChinese));
				tb.addCell(ccc3);
			}
		}
		document.add(tb);
					
		ArrayList p1 = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"rzd1.html"),"UTF-8"), st);
		for (int k = 0; k < p1.size(); k++) {  
			String t = p1.get(k).toString().replaceAll("[\\[||\\]]", ""); 
			t = t.replaceAll("\\$\\{realName\\}", user.getRealName());
			t = t.replaceAll("\\$\\{comName\\}", borrowerMerchantInfo.getCorporateName());
			t = t.replaceAll("\\$\\{anxinName\\}",anxinName );
			t = t.replaceAll("\\,\\}", "");
			if(t.length()!=0){ 
				document.add(new Paragraph(t,fontChinese)); 
			} 
		}
		document.close();
	}
	
	
	/**
	 * ********************************************
	 * method name   : produceSignForInvstor 
	 * description   : 生成投资人的借款协议pdf格式
	 * @return       : void
	 * @param        : @param loan
	 * @param        : @param file
	 * @param        : @param user
	 * @param        : @throws Exception
	 * @Exception    : @throws Exception
	 * modified      : 赵静伟 , 2014-7-4下午03:00:42
	 * @see          : 
	 * *******************************************
	 */
	public  void produceSignForInvstor(Loan loan,File file,User user) throws Exception{
		String path = request.getRealPath("/contractTemplate/");
		//常量
		webName = CommonDef.WEBSITE_DOMAIN_NAME;
		//标信息
		//投资人信息s
		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
		//借款人信息
		borrower = userService.getUserByID(loan.getBorrowerId());
		borrowerPersonalInfo = borrowerInfoService.getUserPersonalInfoByLoanId(loanId);
		//合同签订时间，取放标时间
		date = new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime());
		date_day = new SimpleDateFormat("dd").format(loan.getReleaseTime());
		//date_repayStart = nextMonth(loan.getReleaseTime());
		Date end = loan.getReleaseTime();
		
		//lj mod 增加一次性还本付息的处理 这里简单处理，认为是以天为单位的都是一次还本付息的。
		if (loan.getTermUnit() == 1){
			end = DateTimeUtil.getNextDate(end,loan.getTermCount());
			date_repayStart = new SimpleDateFormat("yyyy年MM月dd日").format(end);
			date_end = date_repayStart;
		}else{
			date_repayStart = nextMonth(end);
			for(int i = 0;i<loan.getTermCount();i++){
				date_end = nextMonth(end);
				end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
			}
		}

		String contractNo = "";
		for(LoanInvestor loanInvestor : investorList){
			if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
				contractNo = loanInvestor.getContractNo();
				break;
			}
		}
		
		
		Document document = new Document();
        StyleSheet st = new StyleSheet();
        st.loadTagStyle("body", "leading", "16,0");
        PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        BaseFont bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H", false); 
        Font fontChinese = new Font(bfChinese); 
        ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"a.html"),"UTF-8"), st);
        for(int k = 0; k < p.size(); k++) {  
            String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
            t = t.replaceAll("\\$\\{loanId\\}", contractNo);
            t = t.replaceAll("\\$\\{start\\}", date);
            t = t.replaceAll("\\$\\{end\\}", new SimpleDateFormat("yyyy年MM月dd日").format(end));
            t = t.replaceAll("\\,\\}", "");
            if(t.length()!=0){ 
            document.add(new Paragraph(t,fontChinese)); 
            } 
        }
        Font fontChinesetitle = new Font(bfChinese,Font.BOLD, 16);
        document.newPage(); 
        //协议的主体信息
        document.add(new Paragraph("附录：",fontChinesetitle));
		document.add(new Paragraph("一、	协议主体信息",fontChinese));
		document.add(new Paragraph("甲方（出借人）",fontChinese));
		Table tb = new Table(3, 2);
		int widthtb[] = { 20, 30, 20};
		tb.setWidths(widthtb);
		tb.setWidth(100); // 占页面宽度 %
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		Cell ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(user.getRealName(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(user.getIdCardNo(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(user.getNickName(),fontChinese));
		tb.addCell(ac1);
		document.add(tb);
		document.add(new Paragraph("乙方（借款人）",fontChinese));
		tb = new Table(3, 2);
		tb.setWidths(widthtb);
		tb.setWidth(100); // 占页面宽度 %
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		User borrower = userService.getUserByID(loan.getBorrowerId());
		ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(borrower.getRealName(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(borrower.getIdCardNo(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(borrower.getNickName(),fontChinese));
		tb.addCell(ac1);
		document.add(tb);
		document.add(new Paragraph("丙方（居间平台服务商）：北京放心科技服务有限公司",fontChinese));
		//借款基本信息
		LoanInvestor investor = null;
		for(LoanInvestor loanInvestor : investorList){
			if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
				investor = loanInvestor;
				break;
			}
		}
		document.add(new Paragraph("二、借款基本信息",fontChinese));
		 Table t = new Table(2, 6);
			int width[] = { 20, 40};
			t.setWidths(width);
			t.setWidth(100); // 占页面宽度 %
			t.setPadding(1);
			t.setSpacing(0);
			t.setBorderWidth(1);
			
			Cell c2 = new Cell(new Paragraph("借款本金数额",fontChinese));
			t.addCell(c2);
			c2 = new Cell(new Paragraph("人民币【"+loan.getAmount().toString()+"】元",fontChinese));
			t.addCell(c2);
			
			Cell c3 = new Cell(new Paragraph("借款期限",fontChinese));
			t.addCell(c3);
			c3 = new Cell(new Paragraph(loan.getTermCount()+LoanUtil.getTermUnitStr().get(loan.getTermUnit()),fontChinese));
			t.addCell(c3);
			
			Cell c1 = new Cell(new Paragraph("借款用途",fontChinese));
			t.addCell(c1);
			c1 = new Cell(new Paragraph(LoanUtil.getborrowTypeStr().get(loan.getBorrowType()),fontChinese));
			t.addCell(c1);
			
			Cell c6 = new Cell(new Paragraph("还款方式",fontChinese));
			t.addCell(c6);
			c6 = new Cell(new Paragraph(LoanUtil.getProductNameMap().get(loan.getProductId()),fontChinese));
			t.addCell(c6);
			
			c2 = new Cell(new Paragraph("借款年利率",fontChinese));
			t.addCell(c2);
			c2 = new Cell(new Paragraph(loan.getAnnualInterestRate()+"%",fontChinese));
			t.addCell(c2);
			
			Cell c8 = new Cell(new Paragraph("还款日",fontChinese));
			t.addCell(c8);
			if (loan.getProductId().equals(Short.parseShort("2"))){
				c8 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
			}else{
				c8 = new Cell(new Paragraph("每月【"+new SimpleDateFormat("dd").format(loan.getReleaseTime())+"】日（若当月没有该日，则还款日为当月最后一天，节假日不顺延；若该日为休息日的，则还款日为该日前最近的一个工作日）",fontChinese));
			}
			t.addCell(c8);
			document.add(t);
			
//			Cell c4 = new Cell(new Paragraph("借款开始日",fontChinese));
//			t.addCell(c4);
//			c4 = new Cell(new Paragraph(date,fontChinese));
//			t.addCell(c4);
//			Cell c5 = new Cell(new Paragraph("借款到期日",fontChinese));
//			t.addCell(c5);
//			c5 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
//			t.addCell(c5);
//			
//			Cell c7 = new Cell(new Paragraph("还款分期月数",fontChinese));
//			t.addCell(c7);
//			c7 = new Cell(new Paragraph(loan.getTermCount().toString()+"个月",fontChinese));
//			t.addCell(c7);
	    //投资人角色回款计划表	
		document.add(new Paragraph("三、收益时间表",fontChinese));
		//回款计划表
	    List<LoanPhase> loanPhaseList  = investorService.repayToInvestors(loan,investor);
	    Table tttt = new Table(5, loanPhaseList.size()+1);
		int widthtttt[] = { 15, 15, 15, 15, 15};
		tttt.setWidths(widthtttt);
		tttt.setWidth(100); // 占页面宽度 %
		tttt.setPadding(1);
		tttt.setSpacing(0);
		tttt.setBorderWidth(1);
		Cell cccc1 = new Cell(new Paragraph("回款序次数",fontChinese));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("回款时间",fontChinese)));
		tttt.addCell(cccc1);
		Cell cccc2 = new Cell(new Paragraph("本金",fontChinese));
		tttt.addCell(cccc2);
		cccc2 = new Cell(new Paragraph("利息",fontChinese));
		tttt.addCell(cccc2);
		cccc2 = new Cell(new Paragraph("账户管理费",fontChinese));
		tttt.addCell(cccc2);
		//还款计划表中的还款日期
	    List<LoanPhase> phaseList =  borrowerService.getLoanPhaseListbyLoanId(loan.getLoanId());
		for(LoanPhase loanPhase : loanPhaseList){
			Cell cccc3 = new Cell(new Paragraph(loanPhase.getPhaseNumber().toString(),fontChinese));
			tttt.addCell(new Paragraph("第"+loanPhase.getPhaseNumber()+"期",fontChinese));
			Date dueDate = phaseList.get(loanPhase.getPhaseNumber()-1).getDueDate();
			String repayDay = new SimpleDateFormat("yyyy年MM月dd日").format(dueDate);
			cccc3 = new Cell(new Paragraph(repayDay,fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermPrincipal().toString(),fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermInterest().toString(),fontChinese));
			tttt.addCell(cccc3);
			cccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermInterest().multiply(loan.getInvestorMgrFeeRate()).divide(new BigDecimal(100)).setScale(2, BigDecimal.ROUND_HALF_UP).toString(),fontChinese));
			tttt.addCell(cccc3);
		}
		document.add(tttt);
		
		//收费标准
	    document.add(new Paragraph("四、收费规则与金额",fontChinese));
	    tttt = new Table(2, 7);
		int widthtttttt[] = {20, 80};
		tttt.setWidths(widthtttttt);
		tttt.setWidth(100); // 占页面宽度 %
		tttt.setPadding(1);
		tttt.setSpacing(0);
		tttt.setBorderWidth(1);
		cccc1 = new Cell(new Paragraph("收费项目",fontChinese));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("借款人",fontChinese)));
		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("账户托管年费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("用户实名认证费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("充值手续费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("提现手续费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("2元/笔",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("账户管理费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("借款管理费",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("根据借款利率、期限、还款方式及风险评级的不同，按借款总金额年化0-10%计算，放款时一次性收取",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("信用保险费",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("根据风险评级不同，按借款总金额年化0-5%计算，放款时一次性收取",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("借款逾期罚息",fontChinese)));
		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("■逾期天数：1-30天\n√罚息总额=当期逾期本息总额×对应罚息利率×逾期天数\n√日罚息利率 "+AppVars.getInstance().faxiRate1+"%\n√罚息归出借人所有\n■逾期天数：30天以上\n√30天以上，不再累计罚息\n√此前累计罚息归"+AppVars.getInstance().websiteNameCn+"平台所有",fontChinese)));
		cccc1 = new Cell(new Paragraph(new Paragraph("向出借方支付",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("借款逾期管理费",fontChinese)));
		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("■逾期天数：1-30天\n√逾期管理费总额=（当期逾期本息总额+当期借款账户管理费）×对应逾期管理费率×逾期天数\n√逾期管理费率:"+AppVars.getInstance().yuqiRate1+"%\n■逾期天数：30天以上\n√逾期管理费总额=逾期30天内管理费总额+逾期30天后管理费总额\n√逾期30天后管理费总额=（当期逾期本息总额+借款待还本金）×对应逾期管理费率×(逾期天数-30)\n√逾期管理费率:"+AppVars.getInstance().yuqiRate2+"%",fontChinese)));
		cccc1 = new Cell(new Paragraph(new Paragraph("向丙方支付",fontChinese)));
		tttt.addCell(cccc1);
		
		 
		cccc1 = new Cell(new Paragraph(new Paragraph("提前还款补偿",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("向出借方支付（补偿金额为剩余本金的  ％）",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("上门催收提醒费用",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("向丙方支付（人民币1000元／次）",fontChinese)));
		tttt.addCell(cccc1);
		
		document.add(tttt);
		
		document.close();
	}
	/**
	 * 
	 *@name   生成债权转入者合同
	 *@description 生成债权转入者合同
	 *@time    创建时间:2015-8-26上午11:35:49
	 *@param apply
	 *@param file
	 *@param user
	 *@throws Exception
	 *@author   胡必武
	 *@history 修订历史（历次修订内容、修订人、修订时间等）
	 */
	public  void produceCRSignForBuyer(CreditRightsApply apply,File file,User user) throws Exception{
		String path = request.getRealPath("/contractTemplate/");
		//投资信息
		investorList = loanInvestorService.getInvestorListByManagerNo(apply.getId().toString());
//		investorList = loanInvestorService.getInvestorListByLoanid(apply.getLoanId());
		//投资标的
		Loan loan = loanService.getLoanByID(apply.getLoanId());
		//借款人信息
		borrower = userService.getUserByID(loan.getBorrowerId());
		//债权卖出者信息
		crSeller = userService.getUserByID(apply.getSellerUserId());
		Date end = loan.getReleaseTime();
		if (loan.getTermUnit() == 1){
			end = DateTimeUtil.getNextDate(end,loan.getTermCount());
			date_repayStart = new SimpleDateFormat("yyyy年MM月dd日").format(end);
			date_end = date_repayStart;
		}else{
			date_repayStart = nextMonth(end);
			for(int i = 0;i<loan.getTermCount();i++){
				date_end = nextMonth(end);
				end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
			}
		}
		
		String crContractNo = "";
		LoanInvestor invest = null;
		for(LoanInvestor loanInvestor : investorList){
			if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
				crContractNo = loanInvestor.getCrContractNo();
				invest = loanInvestor;
				//合同签订时间，取债权买入时间
				date = new SimpleDateFormat("yyyy年MM月dd日").format(loanInvestor.getInvestTime());
				break;
			}
		}
		
		
		Document document = new Document();
		StyleSheet st = new StyleSheet();
		st.loadTagStyle("body", "leading", "16,0");
		PdfWriter.getInstance(document, new FileOutputStream(file));
		document.open();
		BaseFont bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H", false); 
		Font fontChinese = new Font(bfChinese); 
		ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"b.html"),"UTF-8"), st);
		for(int k = 0; k < p.size(); k++) {  
			String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
			t = t.replaceAll("\\$\\{creditRightId\\}", crContractNo);
			t = t.replaceAll("\\$\\{signTime\\}", date);
			t = t.replaceAll("\\,\\}", "");
			if(t.length()!=0){ 
				document.add(new Paragraph(t,fontChinese)); 
			} 
		}
		Font fontChinesetitle = new Font(bfChinese,Font.BOLD, 16);
		document.newPage(); 
		//协议的主体信息
		document.add(new Paragraph("附录：",fontChinesetitle));
		document.add(new Paragraph("一、	协议主体信息",fontChinese));
		document.add(new Paragraph("甲方（转让人）",fontChinese));
		Table tb = new Table(3, 2);
		int widthtb[] = { 20, 30, 20};
		tb.setWidths(widthtb);
		tb.setWidth(100); 
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		
		Cell ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(crSeller.getRealName(),fontChinese));
		tb.addCell(ac1);
		
		ac1 = new Cell(new Paragraph(crSeller.getIdCardNo(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(crSeller.getNickName(),fontChinese));
		tb.addCell(ac1);
		
		document.add(tb);
		
		document.add(new Paragraph("乙方（受让人）",fontChinese));
		
		tb = new Table(3, 2);
		tb.setWidths(widthtb);
		tb.setWidth(100); 
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		
		ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(user.getRealName(),fontChinese));
		tb.addCell(ac1);
		
		ac1 = new Cell(new Paragraph(user.getIdCardNo(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(user.getNickName(),fontChinese));
		tb.addCell(ac1);
		
		document.add(tb);
		document.add(new Paragraph("二、标的债权信息",fontChinese));
		Table t = new Table(2, 7);
		int width[] = { 20, 40};
		t.setWidths(width);
		t.setWidth(100); 
		t.setPadding(1);
		t.setSpacing(0);
		t.setBorderWidth(1);
		
		ac1 = new Cell(new Paragraph("借款ID",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph(loan.getLoanId().toString(),fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("借款人姓名",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph(borrower.getRealName(),fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("借款本金数额",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph("人民币【"+loan.getAmount().toString()+"】元",fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("借款年利率",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph(loan.getAnnualInterestRate()+"%",fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("原借款期限",fontChinese));
		t.addCell(ac1);
		if(loan.getTermUnit()==Short.parseShort("1")){
			ac1 = new Cell(new Paragraph(loan.getTermCount()+"天,从"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime())+"起，到"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getEndTime())+"止",fontChinese));
		}else if(loan.getTermUnit()==Short.parseShort("3")){
			ac1 = new Cell(new Paragraph(loan.getTermCount()+"个月,从"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime())+"起，到"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getEndTime())+"止",fontChinese));
		}
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("月偿还本息数额",fontChinese));
		t.addCell(ac1);
		String termRepay = "";
		List<LoanPhase> loanPhaseList =  borrowerService.getLoanPhaseListbyLoanId(loan.getLoanId()); 
		for(int i=1;i<loanPhaseList.size()+1;i++){
			termRepay =termRepay+"第" + i + "期【"+loanPhaseList.get(i-1).getPlannedTermAmount()+"】元	";
		}
		t.addCell(new Paragraph(termRepay,fontChinese));
		ac1 = new Cell(new Paragraph("还款日",fontChinese));
		t.addCell(ac1);
		if (loan.getProductId().equals(Short.parseShort("2"))){
			ac1 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
		}else{
			ac1 = new Cell(new Paragraph("每月【"+new SimpleDateFormat("dd").format(loan.getReleaseTime())+"】日（若当月没有该日，则还款日为当月最后一天，节假日不顺延；若该日为休息日的，则还款日为该日前最近的一个工作日）",fontChinese));
		}
		t.addCell(ac1);
		
		document.add(t);
		
		
		document.add(new Paragraph("三、标的债权交易信息",fontChinese));
		Table t3 = new Table(2, 5);
		t3.setWidths(width);
		t3.setWidth(100);
		t3.setPadding(1);
		t3.setSpacing(0);
		t3.setBorderWidth(1);
		
		ac1 = new Cell(new Paragraph("标的债权价值",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph("人民币【"+invest.getInvestAmount().toString()+"】元",fontChinese));
		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("交易价款",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph("人民币【"+invest.getOrigAmount().toString()+"】元",fontChinese));
		t3.addCell(ac1);
		
//		ac1 = new Cell(new Paragraph("交易管理费",fontChinese));
//		t3.addCell(ac1);
//		if(invest.getSoldCommission()==null){
//			ac1 = new Cell(new Paragraph("免费",fontChinese));
//		}else{
//			ac1 = new Cell(new Paragraph("人民币【"+invest.getSoldCommission().toString()+"】元",fontChinese));
//		}
//		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("交易日期",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(invest.getInvestTime()),fontChinese));
		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("剩余还款分期月数",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph(invest.getLeftTermCount().toString()+"期",fontChinese));
		t3.addCell(ac1);
		document.add(t3);
		
		document.close();
	}
	
	
	
	
	/**
	 * ********************************************
	 * method name   : produceSignForBorrower 
	 * description   : 生成借款人的借款协议
	 * @return       : void
	 * @param        : @param loan
	 * @param        : @param file
	 * @param        : @param user
	 * @param        : @throws Exception
	 * @Exception    : @throws Exception
	 * modified      : 赵静伟 , 2014-7-4下午03:02:21
	 * @see          : 
	 * *******************************************
	 */
	public  void produceSignForBorrower(Loan loan,File file,User user) throws Exception{
		String path = request.getRealPath("/contractTemplate/");
		//常量
		webName = CommonDef.WEBSITE_DOMAIN_NAME;
		//标信息
		//投资人信息
		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
		//借款人信息
		borrower = userService.getUserByID(loan.getBorrowerId());
		borrowerPersonalInfo = borrowerInfoService.getUserPersonalInfoByLoanId(loanId);
		//合同签订时间，取放标时间
		Date end = loan.getReleaseTime();
		date = new SimpleDateFormat("yyyy年MM月dd日").format(end);
		date_day = new SimpleDateFormat("dd").format(end);
		//lj mod 增加一次性还本付息的处理 这里简单处理，认为是以天为单位的都是一次还本付息的。
		if (loan.getTermUnit() == 1){
			end = DateTimeUtil.getNextDate(end,loan.getTermCount());
			date_repayStart = new SimpleDateFormat("yyyy年MM月dd日").format(end);
			date_end = date_repayStart;
		}else{
			date_repayStart = nextMonth(end);
			for(int i = 0;i<loan.getTermCount();i++){
				date_end = nextMonth(end);
				end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
			}
		}
		
		
		
		Document document = new Document();
        StyleSheet st = new StyleSheet();
        st.loadTagStyle("body", "leading", "16,0");
        PdfWriter.getInstance(document, new FileOutputStream(file));
        document.open();
        BaseFont bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H", false); 
        Font fontChinese = new Font(bfChinese); 

        ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"a.html"),"UTF-8"), st);
        for(int k = 0; k < p.size(); k++) {  
            String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
            t = t.replaceAll("\\$\\{loanId\\}", loan.getContractNo());
            t = t.replaceAll("\\$\\{start\\}", date);
            t = t.replaceAll("\\$\\{end\\}", new SimpleDateFormat("yyyy年MM月dd日").format(end));
            t = t.replaceAll("\\,\\}", "");
            if(t.length()!=0){ 
            document.add(new Paragraph(t,fontChinese)); 
            } 
        }
        
        Font fontChinesetitle = new Font(bfChinese,Font.BOLD, 16);
        document.newPage(); 
        //协议的主体信息
        document.add(new Paragraph("附录：",fontChinesetitle));
		document.add(new Paragraph("一、	协议主体信息",fontChinese));
		document.add(new Paragraph("甲方（出借人）",fontChinese));
		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
		List<User> userList = new ArrayList<User>();
		for(LoanInvestor loanInvestor : investorList){
			boolean flag = true;
			User investor = userService.getUserByID(loanInvestor.getInvestorUserId());	
			if(userList.size()>0){
				for(User userData : userList){
					if(investor.getUserId().intValue() == userData.getUserId().intValue()){
						flag = false;
						break;
					}
				}
				if(flag){
					userList.add(investor);
				}
			}else{
				userList.add(investor);
			}
		}
        Table tb = new Table(3, userList.size()+1);
		int widthtb[] = { 20, 30, 20};
		tb.setWidths(widthtb);
		tb.setWidth(100); // 占页面宽度 %
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		Cell ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		Cell ac2 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac2);
		for(User investor : userList){
			Cell ac3 = new Cell(new Paragraph(investor.getRealName(),fontChinese));
			tb.addCell(new Paragraph(investor.getRealName(),fontChinese));
			ac3 = new Cell(new Paragraph(investor.getIdCardNo(),fontChinese));
			tb.addCell(ac3);
			ac3 = new Cell(new Paragraph(investor.getNickName(),fontChinese));
			tb.addCell(ac3);
		}
		document.add(tb);
		document.add(new Paragraph("乙方（借款人）",fontChinese));
		tb = new Table(3, investorList.size()+1);
		tb.setWidths(widthtb);
		tb.setWidth(100); // 占页面宽度 %
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		User borrower = userService.getUserByID(loan.getBorrowerId());
		ac1 = new Cell(new Paragraph(borrower.getRealName(),fontChinese));
		tb.addCell(new Paragraph(borrower.getRealName(),fontChinese));
		ac1 = new Cell(new Paragraph(borrower.getIdCardNo(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(borrower.getNickName(),fontChinese));
		tb.addCell(ac1);
		document.add(tb);
		document.add(new Paragraph("丙方（居间平台服务商）：北京放心科技服务有限公司",fontChinese));
		//借款基本信息
		document.add(new Paragraph("二、借款基本信息",fontChinese));
		 Table t = new Table(2, 6);
			int width[] = { 20, 40};
			t.setWidths(width);
			t.setWidth(100); // 占页面宽度 %
			t.setPadding(1);
			t.setSpacing(0);
			t.setBorderWidth(1);
			
			Cell c2 = new Cell(new Paragraph("借款本金数额",fontChinese));
			t.addCell(c2);
			c2 = new Cell(new Paragraph("人民币【"+loan.getAmount().toString()+"】元",fontChinese));
			t.addCell(c2);
			
			Cell c3 = new Cell(new Paragraph("借款期限",fontChinese));
			t.addCell(c3);
			c3 = new Cell(new Paragraph(loan.getTermCount()+LoanUtil.getTermUnitStr().get(loan.getTermUnit()),fontChinese));
			t.addCell(c3);
			
			Cell c1 = new Cell(new Paragraph("借款用途",fontChinese));
			t.addCell(c1);
			c1 = new Cell(new Paragraph(LoanUtil.getborrowTypeStr().get(loan.getBorrowType()),fontChinese));
			t.addCell(c1);
			
			Cell c6 = new Cell(new Paragraph("还款方式",fontChinese));
			t.addCell(c6);
			c6 = new Cell(new Paragraph(LoanUtil.getProductNameMap().get(loan.getProductId()),fontChinese));
			t.addCell(c6);
			
			c2 = new Cell(new Paragraph("借款年利率",fontChinese));
			t.addCell(c2);
			c2 = new Cell(new Paragraph(loan.getAnnualInterestRate()+"%",fontChinese));
			t.addCell(c2);
			
			Cell c8 = new Cell(new Paragraph("还款日",fontChinese));
			t.addCell(c8);
			if (loan.getProductId().equals(Short.parseShort("2"))){
				c8 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
			}else{
				c8 = new Cell(new Paragraph("每月【"+new SimpleDateFormat("dd").format(loan.getReleaseTime())+"】日（若当月没有该日，则还款日为当月最后一天，节假日不顺延；若该日为休息日的，则还款日为该日前最近的一个工作日）",fontChinese));
			}
			t.addCell(c8);
			document.add(t);
			
//			Cell c4 = new Cell(new Paragraph("借款开始日",fontChinese));
//			t.addCell(c4);
//			c4 = new Cell(new Paragraph(date,fontChinese));
//			t.addCell(c4);
//			Cell c5 = new Cell(new Paragraph("借款到期日",fontChinese));
//			t.addCell(c5);
//			c5 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
//			t.addCell(c5);
//			
//			Cell c7 = new Cell(new Paragraph("还款分期月数",fontChinese));
//			t.addCell(c7);
//			c7 = new Cell(new Paragraph(loan.getTermCount().toString()+"个月",fontChinese));
//			t.addCell(c7);
			
			//借款人角色	还款计划表
		    document.add(new Paragraph("三、还款时间表",fontChinese));
			//还款计划表
		    List<LoanPhase> loanPhaseList =  borrowerService.getLoanPhaseListbyLoanId(loanId); 
		    Table tttt = new Table(5, loanPhaseList.size()+1);
			int widthtttt[] = { 15, 15, 15, 15, 15};
			tttt.setWidths(widthtttt);
			tttt.setWidth(100); // 占页面宽度 %
			tttt.setPadding(1);
			tttt.setSpacing(0);
			tttt.setBorderWidth(1);
			Cell cccc1 = new Cell(new Paragraph("还款序次数",fontChinese));
			tttt.addCell(cccc1);
			cccc1 = new Cell(new Paragraph(new Paragraph("还款时间",fontChinese)));
			tttt.addCell(cccc1);
			Cell cccc2 = new Cell(new Paragraph("还本金额",fontChinese));
			tttt.addCell(cccc2);
			cccc2 = new Cell(new Paragraph("还息金额",fontChinese));
			tttt.addCell(cccc2);
			cccc2 = new Cell(new Paragraph("账户管理费",fontChinese));
			tttt.addCell(cccc2);
			for(LoanPhase loanPhase : loanPhaseList){
				Cell cccc3 = new Cell(new Paragraph(loanPhase.getPhaseNumber().toString(),fontChinese));
				tttt.addCell(new Paragraph("第"+loanPhase.getPhaseNumber()+"期",fontChinese));
				String repayDay = new SimpleDateFormat("yyyy年MM月dd日").format(loanPhase.getDueDate());
				cccc3 = new Cell(new Paragraph(repayDay,fontChinese));
				tttt.addCell(cccc3);
				cccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermPrincipal().toString(),fontChinese));
				tttt.addCell(cccc3);
				cccc3 = new Cell(new Paragraph(loanPhase.getPlannedTermInterest().toString(),fontChinese));
				tttt.addCell(cccc3);
				cccc3 = new Cell(new Paragraph(loanPhase.getTransactionFee().toString(),fontChinese));
				tttt.addCell(cccc3);
			}
			document.add(tttt);	
			
		
		
		 if(super.getUser().getRoles()==UserDef.ROLE_BORROWER){
			//投资人信息
			document.add(new Paragraph("四、出借人列表",fontChinese));
			investorList = loanInvestorService.getInvestorListByLoanid(loanId);
	        Table ttttt = new Table(4, investorList.size()+1);
			int widthttttt[] = { 20, 30, 20, 30};
			ttttt.setWidths(widthttttt);
			ttttt.setWidth(100); // 占页面宽度 %
			ttttt.setPadding(1);
			
			ttttt.setSpacing(0);
			ttttt.setBorderWidth(1);
			Cell ccccc1 = new Cell(new Paragraph("姓名",fontChinese));
			ttttt.addCell(ccccc1);
			ccccc1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
			ttttt.addCell(ccccc1);
			Cell ccccc2 = new Cell(new Paragraph(AppVars.getInstance().websiteNameCn+"用户名",fontChinese));
			ttttt.addCell(ccccc2);
			ccccc2 = new Cell(new Paragraph("借款金额",fontChinese));
			ttttt.addCell(ccccc2);
			for(LoanInvestor loanInvestor : investorList){
				User investor = userService.getUserByID(loanInvestor.getInvestorUserId());
				Cell ccccc3 = new Cell(new Paragraph(investor.getRealName(),fontChinese));
				ttttt.addCell(new Paragraph(investor.getRealName(),fontChinese));
				ccccc3 = new Cell(new Paragraph(investor.getIdCardNo(),fontChinese));
				ttttt.addCell(ccccc3);
				ccccc3 = new Cell(new Paragraph(investor.getNickName(),fontChinese));
				ttttt.addCell(ccccc3);
				ccccc3 = new Cell(new Paragraph(loanInvestor.getInvestAmount()+"元",fontChinese));
				ttttt.addCell(ccccc3);
			}
			document.add(ttttt);
			document.add(new Paragraph("五、收费项目与收费标准",fontChinese));
	     }else{
	    	 document.add(new Paragraph("四、收费项目与收费标准",fontChinese)); 
	     }
		 
		 
		 
		 
//		//其他收费项目
//	    
//	    document.add(new Paragraph("注：以下收费，由放款后丙方向乙方一次性收取。",fontChinese));
//	    tttt = new Table(2, 3);
//		int widthttttt[] = { 30, 30};
//		tttt.setWidths(widthttttt);
//		tttt.setWidth(100); // 占页面宽度 %
//		tttt.setPadding(1);
//		tttt.setSpacing(0);
//		tttt.setBorderWidth(1);
//		cccc1 = new Cell(new Paragraph("收费项",fontChinese));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("金额",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph("风险准备金",fontChinese));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(String.valueOf(LoanUtil.getRiskFee(loan)),fontChinese));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph("居间服务费",fontChinese));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(String.valueOf(LoanUtil.getIntermediaryFee(loan)),fontChinese));
//		tttt.addCell(cccc1);
//		document.add(tttt);	
//		 
//		
//		
//		
//		//收费标准
//	    document.add(new Paragraph("六、收费标准",fontChinese));
	    tttt = new Table(2, 7);
		int widthtttttt[] = {20, 80};
		tttt.setWidths(widthtttttt);
		tttt.setWidth(100); // 占页面宽度 %
		tttt.setPadding(1);
		tttt.setSpacing(0);
		tttt.setBorderWidth(1);
		cccc1 = new Cell(new Paragraph("收费项目",fontChinese));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("借款人",fontChinese)));
		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("账户托管年费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("用户实名认证费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("充值手续费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("提现手续费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("2元/笔",fontChinese)));
//		tttt.addCell(cccc1);
//		
//		cccc1 = new Cell(new Paragraph(new Paragraph("账户管理费",fontChinese)));
//		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("优惠期内免费",fontChinese)));
//		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("借款管理费",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("根据借款利率、期限、还款方式及风险评级的不同，按借款总金额年化0-10%计算，放款时一次性收取",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("信用保险费",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("根据风险评级不同，按借款总金额年化0-5%计算，放款时一次性收取",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("借款逾期罚息",fontChinese)));
		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("■逾期天数：1-30天\n√罚息总额=当期逾期本息总额×对应罚息利率×逾期天数\n√日罚息利率 "+AppVars.getInstance().faxiRate1+"%\n√罚息归出借人所有\n■逾期天数：30天以上\n√30天以上，不再累计罚息\n√此前累计罚息归"+AppVars.getInstance().websiteNameCn+"平台所有",fontChinese)));
		cccc1 = new Cell(new Paragraph(new Paragraph("向出借方支付",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("借款逾期管理费",fontChinese)));
		tttt.addCell(cccc1);
//		cccc1 = new Cell(new Paragraph(new Paragraph("■逾期天数：1-30天\n√逾期管理费总额=（当期逾期本息总额+当期借款账户管理费）×对应逾期管理费率×逾期天数\n√逾期管理费率:"+AppVars.getInstance().yuqiRate1+"%\n■逾期天数：30天以上\n√逾期管理费总额=逾期30天内管理费总额+逾期30天后管理费总额\n√逾期30天后管理费总额=（当期逾期本息总额+借款待还本金）×对应逾期管理费率×(逾期天数-30)\n√逾期管理费率:"+AppVars.getInstance().yuqiRate2+"%",fontChinese)));
		cccc1 = new Cell(new Paragraph(new Paragraph("向丙方支付",fontChinese)));
		tttt.addCell(cccc1);
		
		 
		cccc1 = new Cell(new Paragraph(new Paragraph("提前还款补偿",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("向出借方支付（补偿金额为剩余本金的  ％）",fontChinese)));
		tttt.addCell(cccc1);
		
		cccc1 = new Cell(new Paragraph(new Paragraph("上门催收提醒费用",fontChinese)));
		tttt.addCell(cccc1);
		cccc1 = new Cell(new Paragraph(new Paragraph("向丙方支付（人民币1000元／次）",fontChinese)));
		tttt.addCell(cccc1);
		
		document.add(tttt);
		
		document.close();
	}
	
	
	/**
	 *@name    生成债转转让者合同
	 *@description 相关说明
	 *@time    创建时间:2015-8-26上午11:33:52
	 *@param loan
	 *@param file
	 *@param user
	 *@throws Exception
	 *@author   胡必武
	 *@history 修订历史（历次修订内容、修订人、修订时间等）
	 */
	public  void produceCRSignForSeller(CreditRightsApply apply,File file,User user) throws Exception{
		String path = request.getRealPath("/contractTemplate/");
		//投资信息
		investorList = loanInvestorService.getInvestorListByManagerNo(apply.getId().toString());
		//投资标的
		Loan loan = loanService.getLoanByID(apply.getLoanId());
		//借款人信息
		borrower = userService.getUserByID(loan.getBorrowerId());
		//债权卖出者信息
		crSeller = userService.getUserByID(apply.getSellerUserId());
		//债权对应投资
		LoanInvestor invest = loanInvestorService.getLoanInvestorTransferredById(apply.getLoanInvestId());
		Date end = loan.getReleaseTime();
		if (loan.getTermUnit() == 1){
			end = DateTimeUtil.getNextDate(end,loan.getTermCount());
			date_repayStart = new SimpleDateFormat("yyyy年MM月dd日").format(end);
			date_end = date_repayStart;
		}else{
			date_repayStart = nextMonth(end);
			for(int i = 0;i<loan.getTermCount();i++){
				date_end = nextMonth(end);
				end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
			}
		}
		
		String crContractNo = apply.getCrContractNo();
		Document document = new Document();
		StyleSheet st = new StyleSheet();
		st.loadTagStyle("body", "leading", "16,0");
		PdfWriter.getInstance(document, new FileOutputStream(file));
		document.open();
		BaseFont bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H", false); 
		Font fontChinese = new Font(bfChinese); 
		ArrayList p = HTMLWorker.parseToList(new InputStreamReader(new FileInputStream(path+File.separatorChar+"b.html"),"UTF-8"), st);
		for(int k = 0; k < p.size(); k++) {  
			String t = p.get(k).toString().replaceAll("[\\[||\\]]", ""); 
			t = t.replaceAll("\\$\\{creditRightId\\}", crContractNo);
			//取最后一个债权购买时间
			t = t.replaceAll("\\$\\{signTime\\}", new SimpleDateFormat("yyyy年MM月dd日").format(investorList.get(investorList.size()-1).getInvestTime()));
			t = t.replaceAll("\\,\\}", "");
			if(t.length()!=0){ 
				document.add(new Paragraph(t,fontChinese)); 
			} 
		}
		Font fontChinesetitle = new Font(bfChinese,Font.BOLD, 16);
		document.newPage(); 
		//协议的主体信息
		document.add(new Paragraph("附录：",fontChinesetitle));
		document.add(new Paragraph("一、	协议主体信息",fontChinese));
		document.add(new Paragraph("甲方（转让人）",fontChinese));
		Table tb = new Table(3, 2);
		int widthtb[] = { 20, 30, 20};
		tb.setWidths(widthtb);
		tb.setWidth(100); 
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		
		Cell ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(crSeller.getRealName(),fontChinese));
		tb.addCell(ac1);
		
		ac1 = new Cell(new Paragraph(crSeller.getIdCardNo(),fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(crSeller.getNickName(),fontChinese));
		tb.addCell(ac1);
		
		document.add(tb);
		
		document.add(new Paragraph("乙方（受让人）",fontChinese));
		tb = new Table(4, investorList.size()+1);
		int[] widthtb2 = { 15,20, 20, 15};
		tb.setWidths(widthtb2);
		tb.setWidth(100); 
		tb.setPadding(1);
		tb.setSpacing(0);
		tb.setBorderWidth(1);
		
		ac1 = new Cell(new Paragraph("姓名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph(new Paragraph("身份证号",fontChinese)));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph("安心投用户名",fontChinese));
		tb.addCell(ac1);
		ac1 = new Cell(new Paragraph("债权交易金额",fontChinese));
		tb.addCell(ac1);
		BigDecimal totolTransferAmount = BigDecimal.ZERO;
		for(LoanInvestor loanInvestor : investorList){
			User buyer = userService.getUserByID(loanInvestor.getInvestorUserId());
			ac1 = new Cell(new Paragraph(buyer.getRealName(),fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(buyer.getIdCardNo(),fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph(buyer.getNickName(),fontChinese));
			tb.addCell(ac1);
			ac1 = new Cell(new Paragraph("人民币【"+loanInvestor.getOrigAmount()+"】元",fontChinese));
			tb.addCell(ac1);
			totolTransferAmount = totolTransferAmount.add(loanInvestor.getOrigAmount());
		}
		document.add(tb);
		
		BigDecimal investAmount= BigDecimal.ZERO;
		LoanInvestor investor = null;
		for(LoanInvestor loanInvestor : investorList){
			if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
				investAmount = loanInvestor.getInvestAmount();
				investor = loanInvestor;
				break;
			}
		}
		document.add(new Paragraph("二、标的债权信息",fontChinese));
		Table t = new Table(2, 7);
		int width[] = { 20, 40};
		t.setWidths(width);
		t.setWidth(100); 
		t.setPadding(1);
		t.setSpacing(0);
		t.setBorderWidth(1);
		
		ac1 = new Cell(new Paragraph("借款ID",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph(loan.getLoanId().toString(),fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("借款人姓名",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph(borrower.getRealName(),fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("借款本金数额",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph("人民币【"+loan.getAmount().toString()+"】元",fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("借款年利率",fontChinese));
		t.addCell(ac1);
		ac1 = new Cell(new Paragraph(loan.getAnnualInterestRate()+"%",fontChinese));
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("原借款期限",fontChinese));
		t.addCell(ac1);
		if(loan.getTermUnit()==Short.parseShort("1")){
			ac1 = new Cell(new Paragraph(loan.getTermCount()+"天,从"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime())+"起，到"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getEndTime())+"止",fontChinese));
		}else if(loan.getTermUnit()==Short.parseShort("3")){
			ac1 = new Cell(new Paragraph(loan.getTermCount()+"个月,从"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime())+"起，到"+new SimpleDateFormat("yyyy年MM月dd日").format(loan.getEndTime())+"止",fontChinese));
		}
		t.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("月偿还本息数额",fontChinese));
		t.addCell(ac1);
		List<LoanPhase> loanPhaseList =  borrowerService.getLoanPhaseListbyLoanId(loan.getLoanId());
		String termRepay = "";
		for(int i=1;i<loanPhaseList.size()+1;i++){
			termRepay =termRepay+"第【" + i + "】期"+loanPhaseList.get(i-1).getPlannedTermAmount()+"元";
		}
		t.addCell(new Paragraph(termRepay,fontChinese));
		ac1 = new Cell(new Paragraph("还款日",fontChinese));
		t.addCell(ac1);
		if (loan.getProductId().equals(Short.parseShort("2"))){
			ac1 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(end),fontChinese));
		}else{
			ac1 = new Cell(new Paragraph("每月【"+new SimpleDateFormat("dd").format(loan.getReleaseTime())+"】日（若当月没有该日，则还款日为当月最后一天，节假日不顺延；若该日为休息日的，则还款日为该日前最近的一个工作日）",fontChinese));
		}
		t.addCell(ac1);
		
		document.add(t);
		
		
		document.add(new Paragraph("三、标的债权转让信息",fontChinese));
		Table t3 = new Table(2, 5);
		t3.setWidths(width);
		t3.setWidth(100);
		t3.setPadding(1);
		t3.setSpacing(0);
		t3.setBorderWidth(1);
		
		ac1 = new Cell(new Paragraph("标的债权价值",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph("人民币【"+invest.getInvestAmount().add(invest.getTransferAmount()).toString()+"】元",fontChinese));
		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("转让价款",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph("人民币【"+totolTransferAmount.toString()+"】元",fontChinese));
		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("转让管理费",fontChinese));
		t3.addCell(ac1);
		if(invest.getSoldCommission()==null){
			ac1 = new Cell(new Paragraph("免费",fontChinese));
		}else{
			ac1 = new Cell(new Paragraph("人民币【"+invest.getSoldCommission().toString()+"】元",fontChinese));
		}
		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("转让日期",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph(new SimpleDateFormat("yyyy年MM月dd日").format(invest.getInvestTime()),fontChinese));
		t3.addCell(ac1);
		
		ac1 = new Cell(new Paragraph("剩余还款分期月数",fontChinese));
		t3.addCell(ac1);
		ac1 = new Cell(new Paragraph(invest.getLeftTermCount().toString()+"期",fontChinese));
		t3.addCell(ac1);
		document.add(t3);
		
		document.close();
	}
	
	
	
	
	
	
	//每月还款额计算
	//[贷款本金×月利率×（1+月利率）^还款月数]÷[（1+月利率）^还款月数－1]
	 public static double monthRepay(double cash,double rate,double month){      
		 double p = 0.00;     
		 p = (cash*(rate/12/100)*Math.pow((1+(rate/12/100)),month))/(Math.pow((1+(rate/12/100)),(month))-1);
		 return p;         
	}
	
	 public String nextMonth(Date date){  
		 int year=Integer.parseInt(new SimpleDateFormat("yyyy").format(date));//取到年份值  
		 int month=Integer.parseInt(new SimpleDateFormat("MM").format(date))+1;//取到月份值  
		 int day=Integer.parseInt(new SimpleDateFormat("dd").format(date));//取到天值  
		 if(month==0){  
		     year-=1;month=12;  
		 }  
		 else if(day>28){  
		     if(month==2){  
		         if(year%400==0||(year %4==0&&year%100!=0)){  
		             day=29;  
		         }else day=28;  
		     }else if((month==4||month==6||month==9||month==11)&&day==31)  
		     {  
		         day=30;  
		     }  
		 }  
		 String y = year+"";String m ="";String d ="";  
		 if(month<10) m = "0"+month;  
		 else m=month+"";  
		 if(day<10) d = "0"+day;  
		 else d = day+"";  
		 return y+"年"+m+"月"+d +"日";  
	 }	 
	 
	 
	 public Map<String,String> getborrowTypeStr(){
		 Map<String, String> userMap = new HashMap<String, String>();
		 userMap.put("1", "短期周转");
		 userMap.put("2", "购房借款");
		 userMap.put("3", "购车借款");
		 userMap.put("4", "装修借款");
		 userMap.put("5", "投资创业");
		 userMap.put("6", "个人消费");
		 userMap.put("7", "其他借款");
		return userMap; 
	 }
	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public IBorrowerInfoService getBorrowerInfoService() {
		return borrowerInfoService;
	}

	public void setBorrowerInfoService(IBorrowerInfoService borrowerInfoService) {
		this.borrowerInfoService = borrowerInfoService;
	}

	public ILoanService getLoanService() {
		return loanService;
	}

	public void setLoanService(ILoanService loanService) {
		this.loanService = loanService;
	}

	public ILoanInvestorService getLoanInvestorService() {
		return loanInvestorService;
	}

	public void setLoanInvestorService(ILoanInvestorService loanInvestorService) {
		this.loanInvestorService = loanInvestorService;
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public List<LoanInvestor> getInvestorList() {
		return investorList;
	}

	public void setInvestorList(List<LoanInvestor> investorList) {
		this.investorList = investorList;
	}

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public BorrowerPersonalInfo getBorrowerPersonalInfo() {
		return borrowerPersonalInfo;
	}

	public void setBorrowerPersonalInfo(BorrowerPersonalInfo borrowerPersonalInfo) {
		this.borrowerPersonalInfo = borrowerPersonalInfo;
	}

	public User getBorrower() {
		return borrower;
	}

	public void setBorrower(User borrower) {
		this.borrower = borrower;
	}

	public String getWebName() {
		return webName;
	}

	public void setWebName(String webName) {
		this.webName = webName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDate_day() {
		return date_day;
	}

	public void setDate_day(String date_day) {
		this.date_day = date_day;
	}

	public String getDate_end() {
		return date_end;
	}

	public void setDate_end(String date_end) {
		this.date_end = date_end;
	}


	public String getDate_repayStart() {
		return date_repayStart;
	}


	public void setDate_repayStart(String date_repayStart) {
		this.date_repayStart = date_repayStart;
	}

	public String getMonthRepay() {
		return monthRepay;
	}

	public void setMonthRepay(String monthRepay) {
		this.monthRepay = monthRepay;
	}


	public String getLastMonthRepay() {
		return lastMonthRepay;
	}


	public void setLastMonthRepay(String lastMonthRepay) {
		this.lastMonthRepay = lastMonthRepay;
	}


	/**
	 * @return the investorService
	 */
	public IInvestorService getInvestorService() {
		return investorService;
	}


	/**
	 * @param investorService the investorService to set
	 */
	public void setInvestorService(IInvestorService investorService) {
		this.investorService = investorService;
	}


	/**
	 * @return the loanPhaseList
	 */
	public List<LoanPhase> getLoanPhaseList() {
		return loanPhaseList;
	}


	/**
	 * @param loanPhaseList the loanPhaseList to set
	 */
	public void setLoanPhaseList(List<LoanPhase> loanPhaseList) {
		this.loanPhaseList = loanPhaseList;
	}


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the borrowerService
	 */
	public IBorrowerService getBorrowerService() {
		return borrowerService;
	}


	/**
	 * @param borrowerService the borrowerService to set
	 */
	public void setBorrowerService(IBorrowerService borrowerService) {
		this.borrowerService = borrowerService;
	}


	/**
	 * @return the investorUserList
	 */
	public List<User> getInvestorUserList() {
		return investorUserList;
	}


	/**
	 * @param investorUserList the investorUserList to set
	 */
	public void setInvestorUserList(List<User> investorUserList) {
		this.investorUserList = investorUserList;
	}


	public void setCreditRightsService(ICreditRightsService creditRightsService) {
		this.creditRightsService = creditRightsService;
	}


	public ICreditRightsService getCreditRightsService() {
		return creditRightsService;
	}


	public void setCreditRightApply(CreditRightsApply apply) {
		this.apply = apply;
	}


	public CreditRightsApply getCreditRightApply() {
		return apply;
	}


	public void setCrSeller(User crSeller) {
		this.crSeller = crSeller;
	}


	public User getCrSeller() {
		return crSeller;
	}
}