package com.zkbc.front.invest;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hrt.p2p.api.model.BorrowerPersonalInfo;
import com.hrt.p2p.api.model.Loan;
import com.hrt.p2p.api.model.LoanInvestor;
import com.hrt.p2p.api.model.LoanPhase;
import com.hrt.p2p.api.model.User;
import com.hrt.p2p.bridge.AppVars;
import com.zkbc.base.BaseAction;
import com.hrt.p2p.api.consts.UserDef;
import com.hrt.p2p.exception.PlatformException;
import com.hrt.p2p.api.service.IBorrowerInfoService;
import com.hrt.p2p.api.service.IBorrowerService;
import com.hrt.p2p.api.service.IInvestorService;
import com.hrt.p2p.api.service.ILoanInvestorService;
import com.hrt.p2p.api.service.ILoanService;
import com.hrt.p2p.api.service.IUserService;

public class LoanContractAction extends BaseAction {

	private static final long serialVersionUID = 7484819000898944174L;
	private static Logger logger = LoggerFactory.getLogger(LoanContractAction.class); 
	
	private IUserService userService;
	private IBorrowerInfoService borrowerInfoService;
	private ILoanService loanService;
	private ILoanInvestorService loanInvestorService;
	
	private int loanId;
	private int applyId;
	private Loan loan;
	private int id;
	private List<LoanInvestor> investorList;
	private User borrower;
	private List<User> investorUserList;
	private BorrowerPersonalInfo borrowerPersonalInfo;
	private String webName;
	private String date;
	private String date_day;
	private String date_end;
	private String date_repayStart;
	private String monthRepay;
	private String lastMonthRepay;
	private List<LoanPhase> loanPhaseList;
	private IBorrowerService borrowerService;
	private IInvestorService investorService;
	
	public void loanContract() throws PlatformException, ParseException, Exception{
//		logger.info("开始获取合同用标投标者，标ID：=" + loanId);
//		//常量
//		webName = CommonDef.WEBSITE_DOMAIN_NAME;
//		//标信息
//		loan = loanService.getLoanByID(loanId);
//		//投资人信息
//		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
//		//借款人信息
//		borrower = userService.getUserByID(loan.getBorrowerId());
//		borrowerPersonalInfo = borrowerInfoService.getUserPersonalInfoByLoanId(loanId);
//		//合同签订时间，取放标时间
//		date = new SimpleDateFormat("yyyy年MM月dd日").format(loan.getReleaseTime());
//		date_day = new SimpleDateFormat("dd").format(loan.getReleaseTime());
//		date_repayStart = nextMonth(loan.getReleaseTime());
//		Date end = loan.getReleaseTime();
//		for(int i = 0;i<loan.getTermCount();i++){
//			date_end = nextMonth(end);
//			end = new SimpleDateFormat("yyyy年MM月dd日").parse(date_end);
//		}
//		//每月还款
//		monthRepay = "" + monthRepay(loan.getAmount().doubleValue(),loan.getAnnualInterestRate().doubleValue(),loan.getTermCount());
//		if(monthRepay.length()-monthRepay.indexOf(".")>=3){
//			monthRepay = monthRepay.substring(0,monthRepay.indexOf(".")+3);
//		}
//		//最后一期还款
//		lastMonthRepay = "" + ((Double.parseDouble(monthRepay)*loan.getTermCount()) -(Double.parseDouble(monthRepay)*(loan.getTermCount()-1))) ;
//		if(lastMonthRepay.length()-lastMonthRepay.indexOf(".")>=3){
//			lastMonthRepay = lastMonthRepay.substring(0,lastMonthRepay.indexOf(".")+3);
//		}
//		LoanInvestor investor = null;
//		
//		if(super.getUser().getRoles() == UserDef.ROLE_INVESTOR){
//			for(LoanInvestor loanInvestor : investorList){
//				if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
//					investor = loanInvestor;
//					break;
//				}
//			}
//		}
//		
//		if(super.getUser().getRoles() == UserDef.ROLE_BORROWER){
//			investorUserList = new ArrayList<User>();
//			for(LoanInvestor loanInvestor : investorList){
//				User investUser = userService.getUserByID(loanInvestor.getInvestorUserId());
//				investorUserList.add(investUser);
//			}
//		}
//		
//		String contractNo = "";
//		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
//		//根据文件名来下载
//		if(super.getUser().getRoles()==UserDef.ROLE_INVESTOR){
//			for(LoanInvestor loanInvestor : investorList){
//				if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
//					//投资人角色	
//					contractNo = loanInvestor.getContractNo();
//					break;
//				}
//			}
//			
//		}else{
//			//借款人角色	
//			contractNo = loan.getContractNo();
//		}
//		request.setAttribute("contractNo", contractNo);
//		try {
//		if(super.getUser().getRoles() == UserDef.ROLE_BORROWER){
//			loanPhaseList = borrowerService.getLoanPhaseListbyLoanId(loanId);
//		}else{
//			loanPhaseList = investorService.repayToInvestors(loan, investor);
//		}} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		request.setAttribute("yuqiDays", AppVars.getInstance().yuqiDays);
//		request.setAttribute("faxiRate1", AppVars.getInstance().faxiRate1);
//		request.setAttribute("faxiRate2", AppVars.getInstance().faxiRate2);
//		request.setAttribute("yuqiRate1", AppVars.getInstance().yuqiRate1);
//		request.setAttribute("yuqiRate2", AppVars.getInstance().yuqiRate2);
//		return SUCCESS;
		
		
		//标信息
		loan = loanService.getLoanByID(loanId);
		String contractNo = "";
		investorList = loanInvestorService.getInvestorListByLoanid(loanId);
		//根据文件名来下载
		if(super.getUser().getRoles()==UserDef.ROLE_INVESTOR){
			for(LoanInvestor loanInvestor : investorList){
				if(loanInvestor.getInvestorUserId().intValue() == user.getUserId().intValue() && loanInvestor.getId().intValue()== id){
					//投资人角色	
					contractNo = loanInvestor.getContractNo();
					break;
				}
			}
			
		}else{
			//借款人角色	
			contractNo = loan.getContractNo();
		}
		String filename = contractNo+".pdf";
		String filepath = AppVars.getInstance().picRoot+"/contract/"+loan.getLoanId();
		File dirFile = new File(filepath);
		if(!dirFile.exists()){
			dirFile.mkdirs();
		}
		File contractNoFile = new File(filepath,filename);
		response.setContentType("application/pdf");
        FileInputStream in = new FileInputStream(contractNoFile);
        OutputStream o = response.getOutputStream();
        byte[] b = new byte[1024];
        while ((in.read(b)) != -1) {
            o.write(b);
        }
        o.flush();
        in.close();
        o.close();
		return ;
	}
	
	
	
	
	
	//每月还款额计算
	//[贷款本金×月利率×（1+月利率）^还款月数]÷[（1+月利率）^还款月数－1]
	 public static double monthRepay(double cash,double rate,double month){      
		 double p = 0.00;     
		 p = (cash*(rate/12/100)*Math.pow((1+(rate/12/100)),month))/(Math.pow((1+(rate/12/100)),(month))-1);
		 return p;         
	}
	
	 public String nextMonth(Date date){  
		 int year=Integer.parseInt(new SimpleDateFormat("yyyy").format(date));//取到年份值  
		 int month=Integer.parseInt(new SimpleDateFormat("MM").format(date))+1;//取到鱼粉值  
		 int day=Integer.parseInt(new SimpleDateFormat("dd").format(date));//取到天值  
		 if(month==0){  
		     year-=1;month=12;  
		 }  
		 else if(day>28){  
		     if(month==2){  
		         if(year%400==0||(year %4==0&&year%100!=0)){  
		             day=29;  
		         }else day=28;  
		     }else if((month==4||month==6||month==9||month==11)&&day==31)  
		     {  
		         day=30;  
		     }  
		 }  
		 String y = year+"";String m ="";String d ="";  
		 if(month<10) m = "0"+month;  
		 else m=month+"";  
		 if(day<10) d = "0"+day;  
		 else d = day+"";  
		 return y+"年"+m+"月"+d +"日";  
	 }	 

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public IBorrowerInfoService getBorrowerInfoService() {
		return borrowerInfoService;
	}

	public void setBorrowerInfoService(IBorrowerInfoService borrowerInfoService) {
		this.borrowerInfoService = borrowerInfoService;
	}

	public ILoanService getLoanService() {
		return loanService;
	}

	public void setLoanService(ILoanService loanService) {
		this.loanService = loanService;
	}

	public ILoanInvestorService getLoanInvestorService() {
		return loanInvestorService;
	}

	public void setLoanInvestorService(ILoanInvestorService loanInvestorService) {
		this.loanInvestorService = loanInvestorService;
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public List<LoanInvestor> getInvestorList() {
		return investorList;
	}

	public void setInvestorList(List<LoanInvestor> investorList) {
		this.investorList = investorList;
	}

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public BorrowerPersonalInfo getBorrowerPersonalInfo() {
		return borrowerPersonalInfo;
	}

	public void setBorrowerPersonalInfo(BorrowerPersonalInfo borrowerPersonalInfo) {
		this.borrowerPersonalInfo = borrowerPersonalInfo;
	}

	public User getBorrower() {
		return borrower;
	}

	public void setBorrower(User borrower) {
		this.borrower = borrower;
	}

	public String getWebName() {
		return webName;
	}

	public void setWebName(String webName) {
		this.webName = webName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDate_day() {
		return date_day;
	}

	public void setDate_day(String date_day) {
		this.date_day = date_day;
	}

	public String getDate_end() {
		return date_end;
	}

	public void setDate_end(String date_end) {
		this.date_end = date_end;
	}


	public String getDate_repayStart() {
		return date_repayStart;
	}


	public void setDate_repayStart(String date_repayStart) {
		this.date_repayStart = date_repayStart;
	}

	public String getMonthRepay() {
		return monthRepay;
	}

	public void setMonthRepay(String monthRepay) {
		this.monthRepay = monthRepay;
	}


	public String getLastMonthRepay() {
		return lastMonthRepay;
	}


	public void setLastMonthRepay(String lastMonthRepay) {
		this.lastMonthRepay = lastMonthRepay;
	}


	/**
	 * @return the investorService
	 */
	public IInvestorService getInvestorService() {
		return investorService;
	}


	/**
	 * @param investorService the investorService to set
	 */
	public void setInvestorService(IInvestorService investorService) {
		this.investorService = investorService;
	}


	/**
	 * @return the loanPhaseList
	 */
	public List<LoanPhase> getLoanPhaseList() {
		return loanPhaseList;
	}


	/**
	 * @param loanPhaseList the loanPhaseList to set
	 */
	public void setLoanPhaseList(List<LoanPhase> loanPhaseList) {
		this.loanPhaseList = loanPhaseList;
	}


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/**
	 * @return the borrowerService
	 */
	public IBorrowerService getBorrowerService() {
		return borrowerService;
	}


	/**
	 * @param borrowerService the borrowerService to set
	 */
	public void setBorrowerService(IBorrowerService borrowerService) {
		this.borrowerService = borrowerService;
	}


	/**
	 * @return the investorUserList
	 */
	public List<User> getInvestorUserList() {
		return investorUserList;
	}


	/**
	 * @param investorUserList the investorUserList to set
	 */
	public void setInvestorUserList(List<User> investorUserList) {
		this.investorUserList = investorUserList;
	}





	public void setApplyId(int applyId) {
		this.applyId = applyId;
	}





	public int getApplyId() {
		return applyId;
	}
	
	
	
}
